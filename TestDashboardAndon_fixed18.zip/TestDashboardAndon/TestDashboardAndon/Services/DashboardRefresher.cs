using TestDashboardAndon.Models;
using TestDashboardAndon.Services;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace TestDashboardAndon.Services;

public sealed class DashboardRefresher : BackgroundService
{
    private readonly DashboardState _state;
    private readonly SqlAndonRepository _repo;

    private const int REFRESH_SECONDS = 1;
    private const int WS_BUCKET_MINUTES = 1440;

    // How often to ping the database for the UI "DB Connected" indicator.
    private const int DB_PING_SECONDS = 5;

    private static readonly int[] WS_2T = Enumerable.Range(1, 30).ToArray();
    private static readonly int[] WS_SKD = Enumerable.Range(1, 15).ToArray();

    public DashboardRefresher(DashboardState state, SqlAndonRepository repo)
    {
        _state = state;
        _repo = repo;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var timer = new PeriodicTimer(TimeSpan.FromSeconds(REFRESH_SECONDS));

        var tick = 0;

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var now = DateTime.Now;

                var windowStart = SqlAndonRepository.GetActiveWindowStart(now, WS_BUCKET_MINUTES);
                var windowEnd = windowStart.AddMinutes(WS_BUCKET_MINUTES);

                var s2t = await BuildSnapshotAsync("2T", WS_2T, now, windowStart, windowEnd, stoppingToken);
                var skd = await BuildSnapshotAsync("SKD", WS_SKD, now, windowStart, windowEnd, stoppingToken);

                _state.Update(s2t, skd);

                // DB connectivity indicator (non-blocking; short timeout). Only ping every DB_PING_SECONDS.
                if (tick % DB_PING_SECONDS == 0)
                {
                    try
                    {
                        var (andonOk, timerOk, err) = await _repo.CheckConnectionsAsync(stoppingToken);
                        _state.UpdateDbStatus(new DbStatus(
                            AndonConnected: andonOk,
                            TimerConnected: timerOk,
                            LastChecked: now,
                            LastError: err
                        ));

                        // Data / pipeline freshness indicator (based on latest LossTimeEvents entry).
                        try
                        {
                            DateTime? lastEvt = null;
                            string? dataErr = null;

                            if (timerOk)
                            {
                                lastEvt = await _repo.GetLatestLossTimeEventTimeAsync(stoppingToken);
                            }
                            else
                            {
                                dataErr = "Timer DB not connected";
                            }

                            _state.UpdateDataStatus(new DataStatus(
                                LastEventTime: lastEvt,
                                LastChecked: now,
                                LastError: dataErr
                            ));
                        }
                        catch (Exception exData)
                        {
                            _state.UpdateDataStatus(new DataStatus(
                                LastEventTime: null,
                                LastChecked: now,
                                LastError: exData.Message
                            ));
                        }
                    }
                    catch (Exception exDb)
                    {
                        _state.UpdateDbStatus(new DbStatus(
                            AndonConnected: false,
                            TimerConnected: false,
                            LastChecked: now,
                            LastError: exDb.Message
                        ));

                        _state.UpdateDataStatus(new DataStatus(
                            LastEventTime: null,
                            LastChecked: now,
                            LastError: exDb.Message
                        ));
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            tick++;

            await timer.WaitForNextTickAsync(stoppingToken);
        }
    }

    private async Task<LineSnapshot> BuildSnapshotAsync(
        string line, int[] wsList, DateTime now, DateTime windowStart, DateTime windowEnd, CancellationToken ct)
    {
        var snap = new LineSnapshot { Line = line };

        foreach (var ws in wsList)
        {
            snap.Stations[ws] = new WsCard { Line = line, Ws = ws };
        }

        var (old2t, oldskd) = _state.Read();
        var oldSnap = line == "2T" ? old2t : oldskd;
        var latestPerWs = await _repo.GetLatestPerWsAsync(line, ct);
        var activeStarts = await _repo.GetActiveProblemStartTimesAsync(line, ct);

        foreach (var ws in wsList)
        {
            var card = snap.Stations[ws];

            card.ActiveProblem = 0;
            card.ProblemStartTime = null;

            if (latestPerWs.TryGetValue(ws, out var last) && last.value == 1 && last.problem is >= 1 and <= 4)
            {
                card.ActiveProblem = last.problem;

                if (activeStarts.TryGetValue((ws, card.ActiveProblem), out var start))
                {
                    card.ProblemStartTime = start;
                }
                else if (oldSnap.Stations.TryGetValue(ws, out var oldCard) &&
                         oldCard.ActiveProblem == card.ActiveProblem &&
                         oldCard.ProblemStartTime.HasValue)
                {
                    card.ProblemStartTime = oldCard.ProblemStartTime;
                }
                else
                {
                    card.ProblemStartTime = now;
                }
            }
        }

        var wsLossSec = await _repo.GetWsLossActiveWindowSecondsAsync(line, windowStart, windowEnd, now, ct);
        foreach (var kv in wsLossSec)
        {
            var (ws, prob) = kv.Key;
            if (!snap.Stations.TryGetValue(ws, out var card)) continue;

            var txt = SqlAndonRepository.SecondsToHHMMSS(kv.Value);

            if (prob == 1) card.MachineLoss = txt;
            else if (prob == 2) card.MaterialLoss = txt;
            else if (prob == 3) card.OperatorLoss = txt;
            else if (prob == 4) card.QualityLoss = txt;
        }

        snap.Today = await _repo.GetTotalLossAsync("TotalLossTimeDaily3", line, now, ct);
        snap.Monthly = await _repo.GetTotalLossAsync("TotalLossTimeMonthly3", line, now, ct);
        snap.Yearly = await _repo.GetTotalLossAsync("TotalLossTimeYearly3", line, now, ct);

        return snap;
    }
}
//DashboardRefresher.cs
