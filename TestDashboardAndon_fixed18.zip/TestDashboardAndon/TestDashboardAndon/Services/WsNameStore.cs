﻿using System.Text.Json;

namespace TestDashboardAndon.Services;

public sealed class WsNameStore
{
    private readonly string _filePath;
    private readonly object _lock = new();

    private readonly Dictionary<(string line, int ws), string> _names = new();

    private sealed record Entry(string Line, int Ws, string Name);

    public WsNameStore(IWebHostEnvironment env)
    {
        _filePath = Path.Combine(env.ContentRootPath, "ws-names.json");
        LoadFromDisk();
    }

    public string GetName(string line, int ws)
    {
        lock (_lock)
        {
            // OLD (no WS prefix) kept for reference (do not remove):
            // return _names.TryGetValue((line, ws), out var name) && !string.IsNullOrWhiteSpace(name)
            //     ? name
            //     : $"WS-{ws}";

            if (!_names.TryGetValue((line, ws), out var name) || string.IsNullOrWhiteSpace(name))
                return $"WS-{ws}";

            name = name.Trim();
            var prefix = $"WS-{ws}";

            // If user already types the full "WS-x ..." in Settings, don't double-prefix.
            return name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
                ? name
                : $"{prefix} {name}";
        }
    }

    public string GetRawName(string line, int ws)
    {
        lock (_lock)
        {
            return _names.TryGetValue((line, ws), out var name) ? name : string.Empty;
        }
    }

    public void SetName(string line, int ws, string? name)
    {
        lock (_lock)
        {
            var key = (line, ws);
            name ??= string.Empty;

            if (string.IsNullOrWhiteSpace(name))
                _names.Remove(key);
            else
                _names[key] = name.Trim();
        }
    }

    public IReadOnlyList<(string Line, int Ws, string Name)> GetAll()
    {
        lock (_lock)
        {
            return _names
                .Select(kv => (kv.Key.line, kv.Key.ws, kv.Value))
                .OrderBy(x => x.line)
                .ThenBy(x => x.ws)
                .ToList();
        }
    }

    public async Task SaveAsync(CancellationToken ct = default)
    {
        List<Entry> data;
        lock (_lock)
        {
            data = _names
                .Select(kv => new Entry(kv.Key.line, kv.Key.ws, kv.Value))
                .OrderBy(e => e.Line)
                .ThenBy(e => e.Ws)
                .ToList();
        }

        var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
        await File.WriteAllTextAsync(_filePath, json, ct);
    }

    private void LoadFromDisk()
    {
        try
        {
            if (!File.Exists(_filePath)) return;

            var json = File.ReadAllText(_filePath);
            var data = JsonSerializer.Deserialize<List<Entry>>(json) ?? new();

            lock (_lock)
            {
                _names.Clear();
                foreach (var e in data)
                {
                    if (string.IsNullOrWhiteSpace(e.Line)) continue;
                    if (e.Ws <= 0) continue;
                    if (string.IsNullOrWhiteSpace(e.Name)) continue;
                    _names[(e.Line.Trim(), e.Ws)] = e.Name.Trim();
                }
            }
        }
        catch
        {
            // ignore corrupt file
        }
    }
}
//WsNameStore.cs
