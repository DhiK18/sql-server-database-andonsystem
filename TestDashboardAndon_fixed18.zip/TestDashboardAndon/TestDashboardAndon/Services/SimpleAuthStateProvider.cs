﻿using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage;
using System.Security.Claims;

namespace TestDashboardAndon.Services;
public sealed class SimpleAuthStateProvider : AuthenticationStateProvider
{
    private const string StorageKey = "lsbu_andon_auth_user";

    private readonly ProtectedSessionStorage _sessionStorage;
    private readonly AppInstance _appInstance;
    private static readonly ClaimsPrincipal Anonymous = new(new ClaimsIdentity());

    private sealed record AuthTicket(string Username, string InstanceId);

    public SimpleAuthStateProvider(ProtectedSessionStorage sessionStorage, AppInstance appInstance)
    {
        _sessionStorage = sessionStorage;
        _appInstance = appInstance;
    }

    public override async Task<AuthenticationState> GetAuthenticationStateAsync()
    {
        try
        {
            var stored = await _sessionStorage.GetAsync<AuthTicket>(StorageKey);
            if (stored.Success && stored.Value is not null)
            {
                if (!string.Equals(stored.Value.InstanceId, _appInstance.Id, StringComparison.Ordinal))
                {
                    await _sessionStorage.DeleteAsync(StorageKey);
                    return new AuthenticationState(Anonymous);
                }

                if (string.IsNullOrWhiteSpace(stored.Value.Username))
                    return new AuthenticationState(Anonymous);

                var identity = new ClaimsIdentity(
                    new[] { new Claim(ClaimTypes.Name, stored.Value.Username) },
                    authenticationType: "LocalUsernamePassword");

                return new AuthenticationState(new ClaimsPrincipal(identity));
            }
        }
        catch
        {
        }

        return new AuthenticationState(Anonymous);
    }

    public async Task SignInAsync(string username)
    {
        await _sessionStorage.SetAsync(StorageKey, new AuthTicket(username, _appInstance.Id));
        NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
    }

    public async Task SignOutAsync()
    {
        await _sessionStorage.DeleteAsync(StorageKey);
        NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
    }
}
