using Microsoft.Data.SqlClient;
using TestDashboardAndon.Models;

namespace TestDashboardAndon.Services;

public sealed class SqlAndonRepository
{
    private readonly string _andonCs;
    private readonly string _timerCs;

    private string? _lossTimeEventsTwoTColumn;

    public SqlAndonRepository(IConfiguration cfg)
    {
        _andonCs = cfg.GetConnectionString("AndonDb") ?? "";
        _timerCs = cfg.GetConnectionString("TimerDb") ?? "";
    }

    /// <summary>
    /// Quick DB connectivity check for UI indicator. Returns true if the app can open the connection
    /// and execute a trivial query. Uses a small connection timeout to avoid blocking the UI.
    /// </summary>
    public async Task<(bool andonOk, bool timerOk, string? error)> CheckConnectionsAsync(CancellationToken ct)
    {
        bool andonOk = false;
        bool timerOk = false;
        string? lastErr = null;

        if (!string.IsNullOrWhiteSpace(_andonCs))
        {
            try
            {
                await using var con = new SqlConnection(WithTimeout(_andonCs, 2));
                await con.OpenAsync(ct);
                await using var cmd = new SqlCommand("SELECT 1", con);
                _ = await cmd.ExecuteScalarAsync(ct);
                andonOk = true;
            }
            catch (Exception ex)
            {
                lastErr = ex.Message;
            }
        }

        if (!string.IsNullOrWhiteSpace(_timerCs))
        {
            try
            {
                await using var con = new SqlConnection(WithTimeout(_timerCs, 2));
                await con.OpenAsync(ct);
                await using var cmd = new SqlCommand("SELECT 1", con);
                _ = await cmd.ExecuteScalarAsync(ct);
                timerOk = true;
            }
            catch (Exception ex)
            {
                // Keep the most recent error message, but don't overwrite a previous one if it exists.
                lastErr ??= ex.Message;
            }
        }

        return (andonOk, timerOk, lastErr);
    }

    /// <summary>
    /// Latest event timestamp from dbo.LossTimeEvents (TimerDb).
    /// Used as a proxy for Node-RED -> DB data freshness.
    /// </summary>
    public async Task<DateTime?> GetLatestLossTimeEventTimeAsync(CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(_timerCs)) return null;

        await using var con = new SqlConnection(WithTimeout(_timerCs, 2));
        await con.OpenAsync(ct);

        await using var cmd = new SqlCommand("SELECT MAX(eventTime) FROM dbo.LossTimeEvents", con);
        var obj = await cmd.ExecuteScalarAsync(ct);
        if (obj is null || obj == DBNull.Value) return null;
        return Convert.ToDateTime(obj);
    }

    private static string WithTimeout(string cs, int seconds)
    {
        try
        {
            var b = new SqlConnectionStringBuilder(cs)
            {
                ConnectTimeout = Math.Clamp(seconds, 1, 30)
            };
            return b.ConnectionString;
        }
        catch
        {
            return cs;
        }
    }

    public async Task<Dictionary<int, (int problem, int value)>> GetLatestPerWsAsync(string line, CancellationToken ct)
    {
        var result = new Dictionary<int, (int problem, int value)>();

        await using var con = new SqlConnection(_andonCs);
        await con.OpenAsync(ct);

        var sql = @"
SELECT a.workingStation, a.problem, a.value
FROM AndonLogs a
WHERE a.line=@line
AND a.id = (
  SELECT MAX(id)
  FROM AndonLogs
  WHERE line=@line AND workingStation=a.workingStation
);";

        await using var cmd = new SqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@line", line);

        await using var rd = await cmd.ExecuteReaderAsync(ct);
        while (await rd.ReadAsync(ct))
        {
            int ws = Convert.ToInt32(rd["workingStation"]);
            int prob = Convert.ToInt32(rd["problem"]);
            int val = Convert.ToInt32(rd["value"]);
            result[ws] = (prob, val);
        }

        return result;
    }
    public async Task<Dictionary<(int ws, int problem), DateTime>> GetActiveProblemStartTimesAsync(string line, CancellationToken ct)
    {
        // NOTE:
        // Some installations store dbo.LossTimePairs2 in an aggregated form (same problem merged into 1 row).
        // To keep the dashboard consistent with the raw Problem Data Log (dbo.LossTimeEvents),
        // we derive active sessions directly from LossTimeEvents.
        return await GetActiveProblemStartTimesFromEventsAsync(line, ct);
    }

    private async Task<Dictionary<(int ws, int problem), DateTime>> GetActiveProblemStartTimesFromEventsAsync(string line, CancellationToken ct)
    {
        var res = new Dictionary<(int ws, int problem), DateTime>();

        await using var con = new SqlConnection(_timerCs);
        await con.OpenAsync(ct);

        var sql = @"
WITH E AS (
    SELECT id, line, workingStation, problem, value, eventTime,
           LAG(value) OVER (PARTITION BY line, workingStation, problem ORDER BY id) AS prevValue
    FROM dbo.LossTimeEvents
    WHERE line=@line
),
M AS (
    SELECT *,
        CASE WHEN value=1 AND ISNULL(prevValue,0)=0 THEN 1 ELSE 0 END AS startFlag,
        CASE WHEN value=0 AND prevValue=1 THEN 1 ELSE 0 END AS endFlag
    FROM E
),
S AS (
    SELECT *,
        SUM(startFlag) OVER (PARTITION BY line, workingStation, problem ORDER BY id ROWS UNBOUNDED PRECEDING) AS sessionNo
    FROM M
),
Pairs AS (
    SELECT
        line,
        workingStation,
        problem,
        MIN(CASE WHEN startFlag=1 THEN eventTime END) AS firstOnTime,
        MAX(CASE WHEN endFlag=1 THEN eventTime END) AS lastOffTime
    FROM S
    WHERE sessionNo > 0
    GROUP BY line, workingStation, problem, sessionNo
)
SELECT workingStation, problem, firstOnTime
FROM Pairs
WHERE lastOffTime IS NULL;";

        await using var cmd = new SqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@line", line);

        await using var rd = await cmd.ExecuteReaderAsync(ct);
        while (await rd.ReadAsync(ct))
        {
            int ws = Convert.ToInt32(rd["workingStation"]);
            int prob = Convert.ToInt32(rd["problem"]);
            var firstOn = (DateTime)rd["firstOnTime"];

            res[(ws, prob)] = firstOn;
        }

        return res;
    }

    public async Task<Dictionary<(int ws, int problem), long>> GetWsLossActiveWindowSecondsAsync(
        string line, DateTime windowStart, DateTime windowEnd, DateTime now, CancellationToken ct)
    {
        var res = new Dictionary<(int ws, int problem), long>();

        await using var con = new SqlConnection(_timerCs);
        await con.OpenAsync(ct);

        // Derive ON/OFF sessions from dbo.LossTimeEvents (each 0->1 ... 1->0 segment is one row).
        var sql = @"
WITH E AS (
    SELECT id, line, workingStation, problem, value, eventTime,
           LAG(value) OVER (PARTITION BY line, workingStation, problem ORDER BY id) AS prevValue
    FROM dbo.LossTimeEvents
    WHERE line=@line
),
M AS (
    SELECT *,
        CASE WHEN value=1 AND ISNULL(prevValue,0)=0 THEN 1 ELSE 0 END AS startFlag,
        CASE WHEN value=0 AND prevValue=1 THEN 1 ELSE 0 END AS endFlag
    FROM E
),
S AS (
    SELECT *,
        SUM(startFlag) OVER (PARTITION BY line, workingStation, problem ORDER BY id ROWS UNBOUNDED PRECEDING) AS sessionNo
    FROM M
),
Pairs AS (
    SELECT
        line,
        workingStation,
        problem,
        MIN(CASE WHEN startFlag=1 THEN eventTime END) AS firstOnTime,
        MAX(CASE WHEN endFlag=1 THEN eventTime END) AS lastOffTime
    FROM S
    WHERE sessionNo > 0
    GROUP BY line, workingStation, problem, sessionNo
)
SELECT
    workingStation,
    problem,
    SUM(
        CASE
            WHEN
                (CASE WHEN firstOnTime > @ws THEN firstOnTime ELSE @ws END)
                <
                (CASE WHEN ISNULL(lastOffTime, @now) < @we THEN ISNULL(lastOffTime, @now) ELSE @we END)
            THEN DATEDIFF(
                    SECOND,
                    CASE WHEN firstOnTime > @ws THEN firstOnTime ELSE @ws END,
                    CASE WHEN ISNULL(lastOffTime, @now) < @we THEN ISNULL(lastOffTime, @now) ELSE @we END
                 )
            ELSE 0
        END
    ) AS totalSec
FROM Pairs
WHERE firstOnTime < @we
  AND (lastOffTime IS NULL OR lastOffTime > @ws)
GROUP BY workingStation, problem;";

        await using var cmd = new SqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@line", line);
        cmd.Parameters.AddWithValue("@ws", windowStart);
        cmd.Parameters.AddWithValue("@we", windowEnd);
        cmd.Parameters.AddWithValue("@now", now);

        await using var rd = await cmd.ExecuteReaderAsync(ct);
        while (await rd.ReadAsync(ct))
        {
            int ws = Convert.ToInt32(rd["workingStation"]);
            int prob = Convert.ToInt32(rd["problem"]);
            long sec = Convert.ToInt64(rd["totalSec"]);
            if (sec < 0) sec = 0;

            res[(ws, prob)] = sec;
        }

        return res;
    }

    public async Task<TotalLossBlock> GetTotalLossActiveWindowAsync(
        string line, DateTime windowStart, DateTime windowEnd, DateTime now, CancellationToken ct)
    {
        var block = new TotalLossBlock();

        var total = await GetWsLossActiveWindowSecondsAsync(line, windowStart, windowEnd, now, ct);

        long m1 = 0, m2 = 0, m3 = 0, m4 = 0;

        foreach (var kv in total)
        {
            int prob = kv.Key.problem;
            long sec = kv.Value;

            if (prob == 1) m1 += sec;
            else if (prob == 2) m2 += sec;
            else if (prob == 3) m3 += sec;
            else if (prob == 4) m4 += sec;
        }

        block.Machine = SecondsToHHMMSS(m1);
        block.Material = SecondsToHHMMSS(m2);
        block.Operator = SecondsToHHMMSS(m3);
        block.Quality = SecondsToHHMMSS(m4);

        return block;
    }

    public async Task<TotalLossBlock> GetTotalLossAsync(string tableName, string line, DateTime now, CancellationToken ct)
    {
        var block = new TotalLossBlock();
        await using var con = new SqlConnection(_timerCs);
        await con.OpenAsync(ct);

        var qActive = $@"
SELECT TOP 1 periodStart
FROM {tableName}
WHERE line=@line AND @now >= periodStart AND @now < periodEnd
ORDER BY periodStart DESC;";

        DateTime? ps = null;
        await using (var cmd = new SqlCommand(qActive, con))
        {
            cmd.Parameters.AddWithValue("@line", line);
            cmd.Parameters.AddWithValue("@now", now);

            var obj = await cmd.ExecuteScalarAsync(ct);
            if (obj == null) return block;
            ps = (DateTime)obj;
        }

        var qSumMinutes = $@"
SELECT problem, SUM(lossMinutes) totalMin
FROM {tableName}
WHERE line=@line AND periodStart=@ps
GROUP BY problem;";

        
        var qSum = $@"
SELECT problem, SUM(durationSeconds) totalSec
FROM {tableName}
WHERE line=@line AND periodStart=@ps
GROUP BY problem;";

        try
        {
            await using (var cmd = new SqlCommand(qSum, con))
            {
                cmd.Parameters.AddWithValue("@line", line);
                cmd.Parameters.AddWithValue("@ps", ps!.Value);

                await using var rd = await cmd.ExecuteReaderAsync(ct);
                while (await rd.ReadAsync(ct))
                {
                    int prob = Convert.ToInt32(rd["problem"]);
                    long sec = Convert.ToInt64(rd["totalSec"]);
                    var txt = SecondsToHHMMSS(sec);

                    if (prob == 1) block.Machine = txt;
                    else if (prob == 2) block.Material = txt;
                    else if (prob == 3) block.Operator = txt;
                    else if (prob == 4) block.Quality = txt;
                }
            }
        }
        catch (SqlException)
        {
            await using (var cmd = new SqlCommand(qSumMinutes, con))
            {
                cmd.Parameters.AddWithValue("@line", line);
                cmd.Parameters.AddWithValue("@ps", ps!.Value);

                await using var rd = await cmd.ExecuteReaderAsync(ct);
                while (await rd.ReadAsync(ct))
                {
                    int prob = Convert.ToInt32(rd["problem"]);
                    decimal min = Convert.ToDecimal(rd["totalMin"]);
                    var txt = MinutesToHHMMSS(min);

                    if (prob == 1) block.Machine = txt;
                    else if (prob == 2) block.Material = txt;
                    else if (prob == 3) block.Operator = txt;
                    else if (prob == 4) block.Quality = txt;
                }
            }
        }

        return block;
    }

    public async Task<List<LossTimeEventRow>> GetLossTimeEventsAsync(int top, string? lineFilter, int? problemFilter, CancellationToken ct)
    {

        await using var con = new SqlConnection(_timerCs);
        await con.OpenAsync(ct);

        var twoT = await ResolveLossTimeEventsTwoTColumnAsync(con, ct);
        var twoTSelect = string.IsNullOrWhiteSpace(twoT) ? "CAST(NULL AS NVARCHAR(50)) AS TwoT" : $"[{twoT}] AS TwoT";

        var where = "WHERE 1=1";
        if (!string.IsNullOrWhiteSpace(lineFilter)) where += " AND line=@lineFilter";
        if (problemFilter.HasValue) where += " AND problem=@problemFilter";

        var topSql = top > 0 ? "TOP (@top)" : "";

        var sql = $@"
SELECT {topSql}
    id,
    line,
    {twoTSelect},
    workingStation,
    problem,
    value,
    eventTime
FROM dbo.LossTimeEvents
{where}
ORDER BY id DESC;";

        var rows = new List<LossTimeEventRow>();
        await using var cmd = new SqlCommand(sql, con);
        if (top > 0) cmd.Parameters.AddWithValue("@top", top);
        if (!string.IsNullOrWhiteSpace(lineFilter)) cmd.Parameters.AddWithValue("@lineFilter", lineFilter);
        if (problemFilter.HasValue) cmd.Parameters.AddWithValue("@problemFilter", problemFilter.Value);

        await using var rd = await cmd.ExecuteReaderAsync(ct);
        while (await rd.ReadAsync(ct))
        {
            var r = new LossTimeEventRow
            {
                No = Convert.ToInt32(rd["id"]),
                Line = Convert.ToString(rd["line"]) ?? "",
                TwoT = Convert.ToString(rd["TwoT"]) ?? "",
                WorkingStation = Convert.ToInt32(rd["workingStation"]),
                Problem = Convert.ToInt32(rd["problem"]),
                Value = Convert.ToInt32(rd["value"]),
                Time = (DateTime)rd["eventTime"],
            };
            rows.Add(r);
        }

        return rows;
    }
    public async Task<List<LossTimeEventRow>> GetLossTimeEventsAsync(
        int top, string? lineFilter, int? problemFilter, DateTime? fromInclusive, DateTime? toExclusive, CancellationToken ct)
    {

        await using var con = new SqlConnection(_timerCs);
        await con.OpenAsync(ct);

        var twoT = await ResolveLossTimeEventsTwoTColumnAsync(con, ct);
        var twoTSelect = string.IsNullOrWhiteSpace(twoT) ? "CAST(NULL AS NVARCHAR(50)) AS TwoT" : $"[{twoT}] AS TwoT";

        var where = "WHERE 1=1";
        if (!string.IsNullOrWhiteSpace(lineFilter)) where += " AND line=@lineFilter";
        if (problemFilter.HasValue) where += " AND problem=@problemFilter";
        if (fromInclusive.HasValue) where += " AND eventTime >= @from";
        if (toExclusive.HasValue) where += " AND eventTime < @to";

        var topSql = top > 0 ? "TOP (@top)" : "";

        var sql = $@"
SELECT {topSql}
    id,
    line,
    {twoTSelect},
    workingStation,
    problem,
    value,
    eventTime
FROM dbo.LossTimeEvents
{where}
ORDER BY id DESC;";

        var rows = new List<LossTimeEventRow>();
        await using var cmd = new SqlCommand(sql, con);
        if (top > 0) cmd.Parameters.AddWithValue("@top", top);
        if (!string.IsNullOrWhiteSpace(lineFilter)) cmd.Parameters.AddWithValue("@lineFilter", lineFilter);
        if (problemFilter.HasValue) cmd.Parameters.AddWithValue("@problemFilter", problemFilter.Value);
        if (fromInclusive.HasValue) cmd.Parameters.AddWithValue("@from", fromInclusive.Value);
        if (toExclusive.HasValue) cmd.Parameters.AddWithValue("@to", toExclusive.Value);

        await using var rd = await cmd.ExecuteReaderAsync(ct);
        while (await rd.ReadAsync(ct))
        {
            var r = new LossTimeEventRow
            {
                No = Convert.ToInt32(rd["id"]),
                Line = Convert.ToString(rd["line"]) ?? "",
                TwoT = Convert.ToString(rd["TwoT"]) ?? "",
                WorkingStation = Convert.ToInt32(rd["workingStation"]),
                Problem = Convert.ToInt32(rd["problem"]),
                Value = Convert.ToInt32(rd["value"]),
                Time = (DateTime)rd["eventTime"],
            };
            rows.Add(r);
        }

        return rows;
    }



    public async Task<List<LossTimeEventRow>> GetLossTimeEventsAsync(int top, CancellationToken ct)
    {
        await using var con = new SqlConnection(_timerCs);
        await con.OpenAsync(ct);

        var twoT = await ResolveLossTimeEventsTwoTColumnAsync(con, ct);
        var twoTSelect = string.IsNullOrWhiteSpace(twoT) ? "CAST(NULL AS NVARCHAR(50)) AS TwoT" : $"[{twoT}] AS TwoT";

        var topSql = top > 0 ? "TOP (@top)" : "";

        var sql = $@"
SELECT {topSql}
    id,
    line,
    {twoTSelect},
    workingStation,
    problem,
    value,
    eventTime
FROM dbo.LossTimeEvents
ORDER BY id DESC;";

        var rows = new List<LossTimeEventRow>();
        await using var cmd = new SqlCommand(sql, con);
        if (top > 0) cmd.Parameters.AddWithValue("@top", top);

        await using var rd = await cmd.ExecuteReaderAsync(ct);
        while (await rd.ReadAsync(ct))
        {
            var r = new LossTimeEventRow
            {
                No = Convert.ToInt32(rd["id"]),
                Line = Convert.ToString(rd["line"]) ?? "",
                TwoT = Convert.ToString(rd["TwoT"]) ?? "",
                WorkingStation = Convert.ToInt32(rd["workingStation"]),
                Problem = Convert.ToInt32(rd["problem"]),
                Value = Convert.ToInt32(rd["value"]),
                Time = (DateTime)rd["eventTime"],
            };
            rows.Add(r);
        }

        return rows;
    }

    public Task<List<LossTimePairRow>> GetLossTimePairs2Async(int top, string? lineFilter, int? problemFilter, CancellationToken ct)
    {
        return GetLossTimePairs2Async(top, lineFilter, problemFilter, null, null, ct);
    }

    public async Task<List<LossTimePairRow>> GetLossTimePairs2Async(
        int top, string? lineFilter, int? problemFilter, DateTime? fromInclusive, DateTime? toExclusive, CancellationToken ct)
    {
        await using var con = new SqlConnection(_timerCs);
        await con.OpenAsync(ct);

        var topSql = top > 0 ? "TOP (@top)" : "";

        // Build sessions from LossTimeEvents so each ON/OFF period becomes 1 row (no unwanted merging).
        var sql = $@"
WITH E AS (
    SELECT id, line, workingStation, problem, value, eventTime,
           LAG(value) OVER (PARTITION BY line, workingStation, problem ORDER BY id) AS prevValue
    FROM dbo.LossTimeEvents
    WHERE 1=1
      AND (@lineFilter IS NULL OR line=@lineFilter)
      AND (@problemFilter IS NULL OR problem=@problemFilter)
),
M AS (
    SELECT *,
        CASE WHEN value=1 AND ISNULL(prevValue,0)=0 THEN 1 ELSE 0 END AS startFlag,
        CASE WHEN value=0 AND prevValue=1 THEN 1 ELSE 0 END AS endFlag
    FROM E
),
S AS (
    SELECT *,
        SUM(startFlag) OVER (PARTITION BY line, workingStation, problem ORDER BY id ROWS UNBOUNDED PRECEDING) AS sessionNo
    FROM M
),
Pairs AS (
    SELECT
        MAX(id) AS id,
        line,
        workingStation,
        problem,
        MIN(CASE WHEN startFlag=1 THEN eventTime END) AS firstOnTime,
        MAX(CASE WHEN endFlag=1 THEN eventTime END) AS lastOffTime
    FROM S
    WHERE sessionNo > 0
    GROUP BY line, workingStation, problem, sessionNo
)
SELECT {topSql}
    id,
    line,
    workingStation,
    problem,
    CASE
        WHEN lastOffTime IS NOT NULL THEN DATEDIFF(SECOND, firstOnTime, lastOffTime)
        ELSE DATEDIFF(SECOND, firstOnTime, GETDATE())
    END AS durationSec,
    firstOnTime,
    lastOffTime
FROM Pairs
WHERE 1=1
  AND (@from IS NULL OR firstOnTime >= @from)
  AND (@to IS NULL OR firstOnTime < @to)
ORDER BY id DESC;";

        var rows = new List<LossTimePairRow>();
        await using var cmd = new SqlCommand(sql, con);
        if (top > 0) cmd.Parameters.AddWithValue("@top", top);
        cmd.Parameters.AddWithValue("@lineFilter", (object?)lineFilter ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@problemFilter", (object?)problemFilter ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@from", (object?)fromInclusive ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@to", (object?)toExclusive ?? DBNull.Value);

        await using var rd = await cmd.ExecuteReaderAsync(ct);
        while (await rd.ReadAsync(ct))
        {
            DateTime? lastOff = null;
            if (rd["lastOffTime"] != DBNull.Value) lastOff = (DateTime)rd["lastOffTime"];

            var r = new LossTimePairRow
            {
                No = Convert.ToInt32(rd["id"]),
                Line = Convert.ToString(rd["line"]) ?? "",
                WorkingStation = Convert.ToInt32(rd["workingStation"]),
                Problem = Convert.ToInt32(rd["problem"]),
                DurationSec = Convert.ToInt64(rd["durationSec"]),
                FirstOnTime = (DateTime)rd["firstOnTime"],
                LastOffTime = lastOff,
            };
            rows.Add(r);
        }

        return rows;
    }

    public Task<List<LossTimePairRow>> GetLossTimePairs2Async(int top, CancellationToken ct)
    {
        return GetLossTimePairs2Async(top, null, null, null, null, ct);
    }



    private async Task<string> ResolveLossTimeEventsTwoTColumnAsync(SqlConnection con, CancellationToken ct)
    {
        if (_lossTimeEventsTwoTColumn != null) return _lossTimeEventsTwoTColumn;

        var candidates = new[] { "2T", "TwoT", "twoT", "Line2T", "line2T", "Line_2T", "line_2T" };

        foreach (var col in candidates)
        {
            var ok = await ColumnExistsAsync(con, "dbo", "LossTimeEvents", col, ct);
            if (ok)
            {
                _lossTimeEventsTwoTColumn = col;
                return _lossTimeEventsTwoTColumn;
            }
        }

        _lossTimeEventsTwoTColumn = "";
        return _lossTimeEventsTwoTColumn;
    }

    private static async Task<bool> ColumnExistsAsync(
        SqlConnection con, string schema, string table, string column, CancellationToken ct)
    {
        var sql = @"
SELECT COUNT(*)
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA=@s AND TABLE_NAME=@t AND COLUMN_NAME=@c;";

        await using var cmd = new SqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@s", schema);
        cmd.Parameters.AddWithValue("@t", table);
        cmd.Parameters.AddWithValue("@c", column);

        var obj = await cmd.ExecuteScalarAsync(ct);
        var n = Convert.ToInt32(obj);
        return n > 0;
    }

#if false

    public async Task<List<LossTimeEventRow>> GetLossTimeEventsAsync(int top, CancellationToken ct)
    {
        var rows = new List<LossTimeEventRow>();

        await using var con = new SqlConnection(_timerCs);
        await con.OpenAsync(ct);

        var twoTCol = await ResolveLossTimeEventsTwoTColumnAsync(con, ct);
        var twoTSelect = twoTCol is null ? "CAST(NULL AS nvarchar(50)) AS TwoT" : $"[{twoTCol}] AS TwoT";

        var sql = $@"
SELECT TOP (@top)
    id,
    line,
    {twoTSelect},
    workingStation,
    problem,
    value,
    eventTime
FROM dbo.LossTimeEvents
ORDER BY id DESC;";

        await using var cmd = new SqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@top", top);

        await using var rd = await cmd.ExecuteReaderAsync(ct);
        while (await rd.ReadAsync(ct))
        {
            var r = new LossTimeEventRow
            {
                No = Convert.ToInt32(rd["id"]),
                Line = Convert.ToString(rd["line"]) ?? "",
                TwoT = Convert.ToString(rd["TwoT"]) ?? "",
                WorkingStation = Convert.ToInt32(rd["workingStation"]),
                Problem = Convert.ToInt32(rd["problem"]),
                Value = Convert.ToInt32(rd["value"]),
                Time = (DateTime)rd["eventTime"],
            };

            rows.Add(r);
        }

        return rows;
    }

#if false // legacy duplicate (kept for reference)
    public async Task<List<LossTimePairRow>> GetLossTimePairs2Async(int top, CancellationToken ct)
    {
        var rows = new List<LossTimePairRow>();

        await using var con = new SqlConnection(_timerCs);
        await con.OpenAsync(ct);

        var sql = @"
SELECT TOP (@top)
    id,
    line,
    workingStation,
    problem,
    durationSec,
    firstOnTime,
    lastOffTime
FROM dbo.LossTimePairs2
ORDER BY id DESC;";

        await using var cmd = new SqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@top", top);

        await using var rd = await cmd.ExecuteReaderAsync(ct);
        while (await rd.ReadAsync(ct))
        {
            DateTime? lastOff = null;
            if (rd["lastOffTime"] != DBNull.Value) lastOff = (DateTime)rd["lastOffTime"];

            var r = new LossTimePairRow
            {
                No = Convert.ToInt32(rd["id"]),
                Line = Convert.ToString(rd["line"]) ?? "",
                WorkingStation = Convert.ToInt32(rd["workingStation"]),
                Problem = Convert.ToInt32(rd["problem"]),
                DurationSec = Convert.ToInt64(rd["durationSec"]),
                FirstOnTime = (DateTime)rd["firstOnTime"],
                LastOffTime = lastOff,
            };

            rows.Add(r);
        }

        return rows;
    }
#endif

    private async Task<string?> ResolveLossTimeEventsTwoTColumnAsync(SqlConnection con, CancellationToken ct)
    {
        // cache per app lifetime
        if (_lossTimeEventsTwoTColumn is not null) return _lossTimeEventsTwoTColumn;

        // kandidat nama kolom yang sering muncul
        var candidates = new[] { "2T", "TwoT", "twoT", "Line2T", "line2T", "Line_2T", "line_2T" };

        foreach (var c in candidates)
        {
            var q = @"
SELECT COUNT(1)
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA='dbo'
  AND TABLE_NAME='LossTimeEvents'
  AND COLUMN_NAME=@col;";

            await using var cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@col", c);
            var obj = await cmd.ExecuteScalarAsync(ct);
            var n = obj == null ? 0 : Convert.ToInt32(obj);
            if (n > 0)
            {
                _lossTimeEventsTwoTColumn = c;
                return _lossTimeEventsTwoTColumn;
            }
        }

        // tidak ditemukan -> return null, kolom di table page akan kosong
        _lossTimeEventsTwoTColumn = null;
        return null;
    }

#endif

    public static DateTime GetActiveWindowStart(DateTime now, int bucketMinutes)
    {
        int totalMin = now.Hour * 60 + now.Minute;
        int floored = (totalMin / bucketMinutes) * bucketMinutes;
        return new DateTime(now.Year, now.Month, now.Day, floored / 60, floored % 60, 0);
    }

    public static string MinutesToHHMMSS(decimal minutes)
    {
        var ts = TimeSpan.FromSeconds((double)(minutes * 60m));
        if (ts < TimeSpan.Zero) ts = TimeSpan.Zero;

        int hours = (int)ts.TotalHours;
        return $"{hours:00}:{ts.Minutes:00}:{ts.Seconds:00}";
    }

    public static string SecondsToHHMMSS(long seconds)
    {
        if (seconds < 0) seconds = 0;

        var ts = TimeSpan.FromSeconds(seconds);

        int hours = (int)ts.TotalHours;
        return $"{hours:00}:{ts.Minutes:00}:{ts.Seconds:00}";
    }
}
//SqlAndonRepository.cs
