﻿namespace TestDashboardAndon.Models;

public sealed class LineSnapshot

{
    public string Line { get; set; } = "";
    public Dictionary<int, WsCard> Stations { get; set; } = new();

    public TotalLossBlock Today { get; set; } = new();
    public TotalLossBlock Monthly { get; set; } = new();
    public TotalLossBlock Yearly { get; set; } = new();
}
//LineSnapshot.cs