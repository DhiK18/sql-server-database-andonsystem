﻿namespace TestDashboardAndon.Models;

    public sealed class AlertItem
    {
        public string Text { get; set; } = "";
        public bool Problem { get; set; }
    }
