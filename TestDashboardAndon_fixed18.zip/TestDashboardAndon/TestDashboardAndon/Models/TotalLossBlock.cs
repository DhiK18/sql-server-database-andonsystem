﻿namespace TestDashboardAndon.Models;

public class TotalLossBlock
{
    public string Machine { get; set; } = "00:00:00";
    public string Material { get; set; } = "00:00:00";
    public string Operator { get; set; } = "00:00:00";
    public string Quality { get; set; } = "00:00:00";
}
