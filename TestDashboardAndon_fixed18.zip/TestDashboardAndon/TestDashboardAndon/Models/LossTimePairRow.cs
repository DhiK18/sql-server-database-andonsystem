﻿namespace TestDashboardAndon.Models;
public sealed class LossTimePairRow
{
    public int No { get; set; }

    public string Line { get; set; } = "";

    public int WorkingStation { get; set; }

    public int Problem { get; set; }

    public long DurationSec { get; set; }

    public DateTime FirstOnTime { get; set; }

    public DateTime? LastOffTime { get; set; }
}